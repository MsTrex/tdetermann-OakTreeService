﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OakTreeService4.Controllers;
using System.Web.Mvc;

namespace OakTreeService4.Tests.Controllers
{
    [TestClass]
    public class CustomersControllertest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
             CustomersController controller= new CustomersController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
    }

}


