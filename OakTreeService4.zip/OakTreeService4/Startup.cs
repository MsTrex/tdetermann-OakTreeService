﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(OakTreeService4.Startup))]
namespace OakTreeService4
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
